package com.ohgiraffers.test;

public class test1 {
    public static void main(String[] args) {


        int num = 0;
//        System.out.println(num > 0 ? " ": 양수 (num < 0 ? " " : "0") 음수 );
        System.out.println((num > 0)? "양수": (num < 0)? "음수" : "0");
    }
}
